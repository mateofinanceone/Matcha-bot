let handler = m => m.reply('👎 Arra, Astri, Dandi Dan 2Juta Lainnya')
handler.customPrefix = /dislike/i
handler.command = new RegExp
module.exports = handler
