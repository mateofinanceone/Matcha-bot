let handler = m => m.reply('👎 Arra, Astri, Dandi Dan 1Juta Lainnya')
handler.customPrefix = /disslike/i
handler.command = new RegExp
module.exports = handler
